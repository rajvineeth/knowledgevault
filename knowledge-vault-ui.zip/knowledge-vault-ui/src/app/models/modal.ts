export class Modal {
    Node1: string;          // the symptom itself
    Node1label: string;     // the label named symptom
    Relation: string;
    Node2: string;          // the medical condition itself
    Node2label: string;     // the label named medical condition
}
