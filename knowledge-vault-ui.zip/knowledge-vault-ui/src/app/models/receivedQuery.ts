import { Modal } from './modal';
export class ReceivedQuery {
    // medicalInfo: Modal[];
    MedicalSymptom: string;
    MedicalCondition: string;
}
