export class Dummy1 {
    MedicalCondition: String;
    MedicalSymptoms: String[];
}
