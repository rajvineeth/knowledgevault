﻿export * from './register.component';
