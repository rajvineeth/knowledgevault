import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-user',
  templateUrl: './general-user.component.html',
  styleUrls: ['./general-user.component.css']
})
export class GeneralUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
